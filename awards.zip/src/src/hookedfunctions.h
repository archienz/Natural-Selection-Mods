//function declarations for intercepted functions, any function that we want metamod to call needs
//to be declared in this header

#include <extdll.h>

#include <string.h> //to prevent linux errors while processing meta_api.h
#include <meta_api.h>


void ClientCommand( edict_t *pEntity ); //needed for my built-in system for using client commands
int Spawn(edict_t *pEntity); //needed for my built-in system for dynamic sized data
void MessageBeginPost(int msg_type,int msg_name, const float *pOrigin, edict_t *pEntity);
void MessageEndPost();
void MessageBegin(int msg_type,int msg_name, const float *pOrigin, edict_t *pEntity);
void MessageEnd();
void WriteByte(int i);
void WriteString(const char *s);
void StartFrame(void);
int SpawnPost(edict_t *pEntity);
void PlaybackEvent(int flags, const edict_t *pInvoker, unsigned short eventindex, float delay, float *origin, float *angles, float fparam1, float fparam2, int iparam1, int iparam2, int bparam1, int bparam2);
void AlertMessage(ALERT_TYPE atype, char *szFmt, ...);
void ClientDisconnect(edict_t *pEntity);
void ClientPutInServer(edict_t *pEntity);
void PlayerPreThink(edict_t *pEntity);