#include "awards.h"
#ifdef SETTING_UP_CVARS_AND_COMMANDS
//EXAMPLE: DEFINE_CVAR(mp_friendlyfire, FCVAR_SERVER | FCVAR_SPONLY | FCVAR_PRINTABLEONLY , "0", 0 );
DEFINE_CVAR(mp_awardsfile,NULL,"awards.ini",0);
DEFINE_CVAR(mp_damagedraw,FCVAR_SERVER,"0",0);
DEFINE_CVAR(mp_awards,FCVAR_SERVER,"2.1",2.1);
#else

#ifndef _PLUGIN_H_
#define _PLUGIN_H_

#define MY_DATE			"March 30, 2004"
#define MY_NAME			"mm_awards"
#define MY_AUTHOR		"mahnsawce"
#define MY_EMAIL		"steved@crackdealer.com"
#define MY_URL			"www.goatse.cx"
#define MY_LOGTAG		"mm_awards"
#define MY_VERSION		"2.2"
#define MY_LOADABLE		PT_CHANGELEVEL
#define MY_UNLOADABLE	PT_CHANGELEVEL
#define MY_CVARNAME		"mp_awards"

#define MY_VERS_DWORD	2,2,0,0
#define MY_COMMENTS		""
#define MY_DESC			""
#define MY_FILENAME		MY_LOGTAG ".DLL"
#define MY_INTERNAL		MY_LOGTAG
#define MY_COPYRIGHT	"GNU Public License"


#ifndef VERS_PLUGIN_H 
#include <extdll.h>

#include <string.h>
#include <meta_api.h>

#include "utilfunctions.h"

#define DEFINE_CVAR(cvarname, cvarflags, cvarstringvalue, cvarfloatvalue)\
		extern cvar_t * cvar_ ## cvarname; 
#define SETTING_UP_CVARS_AND_COMMANDS
#include "plugin.h"
#undef SETTING_UP_CVARS_AND_COMMANDS

void plugin_init(void);
void plugin_quit(void);

inline void SAFE_USER_MSG(int &gmsgvar, const char *szMsgName, const int &iSize) {
	if(gmsgvar == 0) 
	{
		//attempt to get the msg from the game that's running
		gmsgvar = GET_USER_MSG_ID( &Plugin_info, szMsgName, NULL);
		
		//and if that fails, register it ourselves
		if(gmsgvar == 0) gmsgvar = REG_USER_MSG(szMsgName, iSize);
	}
}




#endif
#endif
#endif



