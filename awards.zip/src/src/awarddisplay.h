void Display_Awards(edict_t *pEntity)
{
	if (ENTINDEX(pEntity) > gpGlobals->maxClients && ENTINDEX(pEntity) < 0)
		return;
	if (player[ENTINDEX(pEntity)].connected==false)
		return;
	if (!pEntity)
		return;
	if (pEntity->free)
		return;
	// General awards
	hudtext.a1 = 0;
	hudtext.a2 = 0;
	hudtext.r2 = 255;
	hudtext.g2 = 255;
	hudtext.b2 = 250;
	hudtext.r1 = kHudTextAllRed;
	hudtext.g1 = kHudTextAllGreen;
	hudtext.b1 = kHudTextAllBlue;
	hudtext.x = kHudTextAllX;
	hudtext.y = kHudTextAllY;
	hudtext.effect = kHudTextEffects;
	hudtext.fxTime = kHudTextfxTime;
	hudtext.holdTime = (float)g_Delay;
	hudtext.fadeinTime = kHudTextFadeIn;
	hudtext.fadeoutTime = kHudTextFadeOut;
	hudtext.channel = kHudTextAllChan;
	HudMessage(pEntity, hudtext,g_GeneralAwards);

	// Marine awards
	hudtext.a1 = 0;
	hudtext.a2 = 0;
	hudtext.r2 = 255;
	hudtext.g2 = 255;
	hudtext.b2 = 250;
	hudtext.r1 = kHudTextMarineRed;
	hudtext.g1 = kHudTextMarineGreen;
	hudtext.b1 = kHudTextMarineBlue;
	hudtext.x = kHudTextMarineX;
	hudtext.y = kHudTextMarineY;
	hudtext.effect = kHudTextEffects;
	hudtext.fxTime = kHudTextfxTime;
	hudtext.holdTime = (float)g_Delay;
	hudtext.fadeinTime = kHudTextFadeIn;
	hudtext.fadeoutTime = kHudTextFadeOut;
	hudtext.channel = kHudTextMarineChan;
	HudMessage(pEntity, hudtext,g_MarineAwards);

	// Alien awards
	hudtext.a1 = 0;
	hudtext.a2 = 0;
	hudtext.r2 = 255;
	hudtext.g2 = 255;
	hudtext.b2 = 250;
	hudtext.r1 = kHudTextAlienRed;
	hudtext.g1 = kHudTextAlienGreen;
	hudtext.b1 = kHudTextAlienBlue;
	hudtext.x = kHudTextAlienX;
	hudtext.y = kHudTextAlienY;
	hudtext.effect = kHudTextEffects;
	hudtext.fxTime = kHudTextfxTime;
	hudtext.holdTime = (float)g_Delay;
	hudtext.fadeinTime = kHudTextFadeIn;
	hudtext.fadeoutTime = kHudTextFadeOut;
	hudtext.channel = kHudTextAlienChan;
	HudMessage(pEntity, hudtext,g_AlienAwards);
}
char *Get_Awards(int awardtype)
{
	char ret[1024];
	ret[0]='\0';
	int i=0;
	int index=0;
	if (awardtype == AWARDCAT_GENERAL)
	{
		Randomize_Awards(awardtype);
		if (Have_Award(AWARDCAT_GENERAL))
		{
			sprintf(ret,"%s\n",g_GeneralHeader);
		}
		for (i=1;i<=g_iGeneralAwards;i++)
		{
			if (Get_Award_Prioritized(AWARDCAT_GENERAL,i) >= 0)
				sprintf(ret,"%s\n%s",ret,Get_Award(AWARDCAT_GENERAL,i));
		}
	}
	else if (awardtype == AWARDCAT_MARINE)
	{
		Randomize_Awards(awardtype);
		if (Have_Award(AWARDCAT_MARINE))
		{
			sprintf(ret,"%s\n",g_MarineHeader);
		}
		for (i=1;i<=g_iMarineAwards;i++)
		{
			if (Get_Award_Prioritized(AWARDCAT_MARINE,i) >= 0)
				sprintf(ret,"%s\n%s",ret,Get_Award(AWARDCAT_MARINE,i));
		}
	}
	else if (awardtype == AWARDCAT_ALIEN)
	{
		Randomize_Awards(awardtype);
		if (Have_Award(AWARDCAT_ALIEN))
		{
			sprintf(ret,"%s\n",g_AlienHeader);
		}
		for (i=1;i<=g_iAlienAwards;i++)
		{
			if (Get_Award_Prioritized(AWARDCAT_ALIEN,i) >= 0)
				sprintf(ret,"%s\n%s",ret,Get_Award(AWARDCAT_ALIEN,i));
		}
	}
	return strdup(ret);
}
char *Get_Award(int awardtype,int awardnum)
{
	char ret[256];
	char temp[256];
	int award=Get_Award_Prioritized(awardtype,awardnum);
	if (award >= 0)
	{
		sprintf(temp,awards[award].display_post,STRING(INDEXENT(Get_Winner(award,0))->v.netname),Get_Winner(award,1));
		sprintf(ret,"%s %s",awards[award].display_pre,temp);
	}
	return strdup(ret);
}
void Randomize_Awards(int awardtype)
{
	// Here's where we create our array for award orders.
	// We need to randomize awards which have the same priority
	int i=0,x=0,y=0,z=0,j=0,k=0,q=0,rand=0;
	int temp[AWARD_MAX];
	for (i=0;i<=AWARD_MAX-1;i++)
	{
		roundawards[i]=-1;
	}
	// Loop through all possible priorities...
	roundawards_count=0;
	for (i=g_HighestPriority;i>0;i--)
	{
		x=0;
		y=0;
		while (awards[x].name)
		{
			if (awards[x].category == awardtype && Got_Award(x))
			{
				if (iiscombat)
				{
					if (awards[x].co_priority == i)
					{
						temp[y]=x;
						y++;
						roundawards_count++;
					}
				}
				else
				{
					if (awards[x].ns_priority == i)
					{
						temp[y]=x;
						y++;
						roundawards_count++;
					}
				}
			}
			x++;
		}
		q=y;
		if (y>0)
		{
			if (y == 1)
			{
				roundawards[z]=temp[0];
				z++;
			}
			else
			{
				// There's more than 1 possible award... let's randomize
				while (y>0)
				{
					rand=RANDOM_LONG(1,q);
					rand--;
					j=0;
					// Loop to make sure the award isn't already in roundawards[]
					for (k=0;k<=z-1;k++)
					{
						if (roundawards[k]==temp[rand])
							j=1;
					}
					if (j==0)
					{
						roundawards[z]=temp[rand];
						z++;
						y--;
					}
				}
			}
		}
	}
}
int Get_Award_Prioritized(int awardtype, int awardnum)
{
	/*
	int i=0,x=0;
	int ret=-1;
	int lowest=-1;
	int count=0;
	for (i=0;i<=AWARD_MAX - 1;i++)
	{
		prioritized[i]=-1;
	}
	i=0;
	while (awards[i].name)
	{
		if (awards[i].category == awardtype)
		{
			if (lowest == -1 && Got_Award(i))
				lowest = i;
			else
			{
				if (iiscombat==1)
				{
					if (awards[lowest].co_priority > awards[i].co_priority && awards[i].co_priority > 0 && Got_Award(i))
						lowest=i;
				}
				else
				{
					if (awards[lowest].ns_priority > awards[i].ns_priority && awards[i].ns_priority > 0 && Got_Award(i))
						lowest=i;
				}
			}
		}
		i++;
	}
	prioritized[count]=lowest;
	count++;
	for (x=0;x<=AWARD_MAX - 1;x++)
	{
		i=0;
		lowest=-1;
		while (awards[i].name)
		{
			if (awards[i].category == awardtype)
			{
				if (lowest==-1)
				{
					if (!Is_Prioritized(i) && Got_Award(i))
					{
						lowest=i;
					}
				}
				else
				{
					if (iiscombat==1)
					{
						if (awards[lowest].co_priority > awards[i].co_priority && !Is_Prioritized(i) && awards[i].co_priority > 0 && Got_Award(i))
							lowest=i;
					}
					else
					{
						if (awards[lowest].ns_priority > awards[i].ns_priority && !Is_Prioritized(i) && awards[i].ns_priority > 0 && Got_Award(i))
							lowest=i;
					}
				}
			}
			i++;	
		}
		if (lowest != -1)
		{
			prioritized[count]=lowest;
			count++;
		}
	}
	count-=awardnum;
	if (count>=0)
	*/
	if (roundawards_count>0)
	{
		return roundawards[awardnum-1];
	}
	return -1;
}
bool Is_Prioritized(int award)
{
	int i;
	for (i=0;i<=AWARD_MAX -1;i++)
	{
		if (prioritized[i]==award)
			return true;
	}
	return false;
}
bool Have_Award(int awardtype)
{
	int i=0;
	while (awards[i].name)
	{
		if (awards[i].category == awardtype)
		{
			if (iiscombat)
			{
				if (awards[i].co_priority > 0)
				{
					if (Got_Award(i))
					{
						return true;
					}
				}
			}
			else
			{
				if (awards[i].ns_priority > 0)
				{
					if (Got_Award(i))
					{
						return true;
					}
				}

			}
		}
		i++;
	}
	
	return false;
}
bool Got_Award(int award)
{
	return Get_Winner(award,2);
}
int Get_Winner(int award,int rettype)
{
	int	win=0;
	int type=0; // 0 = int; 1=float
	float fTemp[33];
	int iTemp[33];
	int i=0;
	for (i=0;i<=32;i++)
	{
		fTemp[i]=0.0;
		iTemp[i]=0;
	}
	if (FStrEq(awards[award].name,"damage"))
	{
		type=1;
		for (i=0;i<=32;i++)
			fTemp[i]=player[i].damage;
	}
	else if (FStrEq(awards[award].name,"shield"))
	{
		type=1;
		for (i=0;i<=32;i++)
			fTemp[i]=player[i].tdamage;
	}
	else if (FStrEq(awards[award].name,"deaths"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].deaths;
	}
	else if (FStrEq(awards[award].name,"suicide"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].suicides;
	}
	else if (FStrEq(awards[award].name,"tk"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].tks;
	}
	else if (FStrEq(awards[award].name,"gest"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].gestdeaths;
	}
	else if (FStrEq(awards[award].name,"built"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].builtstructures;
	}
	else if (FStrEq(awards[award].name,"devkill"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].devourkills;
	}
	else if (FStrEq(awards[award].name,"xenocide"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].xenokills;
	}
	else if (FStrEq(awards[award].name,"destroy"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].destroyedstructures;
	}
	else if (FStrEq(awards[award].name,"stomp"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].stomp;
	}
	else if (FStrEq(awards[award].name,"parasite"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].parasite;
	}
	else if (FStrEq(awards[award].name,"devdeaths"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].devourdeaths;
	}
	else if (FStrEq(awards[award].name,"welder"))
	{
		type=1;
		for (i=0;i<=32;i++)
			fTemp[i]=player[i].weld;
	}
	else if (FStrEq(awards[award].name,"distance"))
	{
		type=1;
		for (i=0;i<=32;i++)
			fTemp[i]=player[i].distance;
	}
	else if (FStrEq(awards[award].name,"knife"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].knifekills;
	}
	else if (FStrEq(awards[award].name,"medpack"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].medpacks;
	}
	else if (FStrEq(awards[award].name,"electricity"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].electricity;
	}
	else if (FStrEq(awards[award].name,"shots"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].shots;
	}
	else if (FStrEq(awards[award].name,"waste"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].waste;
	}
	else if (FStrEq(awards[award].name,"shotgun"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].shotgun;
	}
	else if (FStrEq(awards[award].name,"pistol"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].pistol;
	}
	else if (FStrEq(awards[award].name,"healspray"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].healsprays;
	}
	else if (FStrEq(awards[award].name,"spore"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].spores;
	}
	else if (FStrEq(awards[award].name,"primal"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].primal;
	}
	else if (FStrEq(awards[award].name,"umbra"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].umbra;
	}
	else if (FStrEq(awards[award].name,"reswhore"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].lifeforms;
	}
	else if (FStrEq(awards[award].name,"grenade"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].grenades;
	}
	else if (FStrEq(awards[award].name,"mine"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].minedeaths;
	}
	else if (FStrEq(awards[award].name,"leap"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].leaps;
	}
	else if (FStrEq(awards[award].name,"trigger_hurt"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].trigger_hurt;
	}
	else if (FStrEq(awards[award].name,"worldspawn"))
	{
		for (i=0;i<=32;i++)
			iTemp[i]=player[i].worldspawn;
	}

	if (rettype == 2)
	{
		for (i=1;i<=32;i++)
		{
			if (iTemp[i]>0 || fTemp[i]>0)
				return true;
		}
		return false;
	}
	for (i=1;i<=32;i++)
	{
		if (type) // Checking floats
		{
			if (fTemp[i] > fTemp[win])
			{
				win=i;
			}
		}
		else // Checking ints
		{
			if (iTemp[i] > iTemp[win])
			{
				win=i;
			}
		}
	}
	if (rettype == 0)
		return win;
	if (type)
	{
		if (fTemp[win] < 1.0)
			return 1;
		return (int)fTemp[win];
	}
	return iTemp[win];
}
