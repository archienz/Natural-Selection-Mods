#define AWARD_MAX				33
#define DISTANCE_SCALAR			100 // Every 100 "units" == 1 meter



#define AWARDCAT_NONE			-1
#define AWARDCAT_GENERAL		0
#define AWARDCAT_MARINE			1
#define AWARDCAT_ALIEN			2



#define kHudTextEffects			0
#define kHudTextfxTime			0.0
#define kHudTextHoldTime		20.0
#define kHudTextFadeIn			0.1
#define kHudTextFadeOut			0.1

#define POINTS_BUILT_HIVE		40
#define POINTS_BUILT_RT			15
#define POINTS_BUILT_OC			10
#define POINTS_BUILT_DC			10
#define POINTS_BUILT_MC			10
#define POINTS_BUILT_SC			10

#define POINTS_KILL_HIVE		40
#define POINTS_KILL_RT			15
#define POINTS_KILL_OC			10
#define POINTS_KILL_DC			10
#define POINTS_KILL_MC			10
#define POINTS_KILL_SC			10

// Use these until there's a method to hook upgrade costs (SetUpgCost in old versions).
// Unimplemented.
#define COST_HIVE				40
#define COST_RT					15
#define COST_OC					10
#define COST_DC					10
#define COST_MC					10
#define COST_SC					10
#define COST_UPGRADE			2
#define COST_ONOS				75
#define COST_FADE				50
#define COST_LERK				30
#define COST_GORGE				10
#define COST_SKULK				2
#define COST_HEAVY				15
#define COST_JETPACK			15
#define COST_SHOTGUN			10
#define COST_HMG				15
#define COST_GRENADELAUNCHER	20
#define COST_WELDER				5
#define COST_MINE				10
