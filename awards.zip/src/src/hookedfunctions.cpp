#include "plugin.h"

#include <sdk_util.h>
#include "awards.h"


/* (Taken from Hyper's post)
Awards that can be given to any player:

    o Demolition Man - Player that did the most damage
    o Target Dummy - Player that was killed most
    o I Hate My Life Award - Player with the most suicides
    o Mr. Trigger-Happy - Player that caused the most Teamkills


Awards that can be given to Aliens only:

    o Scrambled Eggs Award - player who died most while gestating
    o Phattey Award - Alien that dropped most buildings (hive counts as two or three maybe?)
    o Kirby[tm] Award - most kills with devour
    o Bomberman - most kills using xenocide


Awards that can be given to Marines only:

    o Wrecking Crew Award - most Alien buildings killed
    o Happy Meal[tm] Award - most killed by devour
    o Golden Wrench - most points recovered (buildings and armor) using the welder
    o Mack the Knife - most kills using knife
*/

// Simple storage; data lost when client disconnects, but this is *so* much easier.

enum
{
	AVH_WEAPON_NONE = 0,

	// Alien weapons
	AVH_WEAPON_CLAWS,
	AVH_WEAPON_SPIT,
	AVH_WEAPON_SPORES,
	AVH_WEAPON_SPIKE,
	AVH_WEAPON_BITE,		// Level 1 bite
	AVH_WEAPON_BITE2,		// Level 3 bite
	AVH_WEAPON_SWIPE,
	AVH_WEAPON_WEBSPINNER,
	AVH_WEAPON_METABOLIZE,
	AVH_WEAPON_PARASITE,
	AVH_WEAPON_BLINK,
	AVH_WEAPON_DIVINEWIND,

	// Adding a new weapon?  Don't forget to add it's weight in AvHGamerules::GetWeightForItemAndAmmo(AvHWeaponID inWeapon, int inNumRounds)
	AVH_WEAPON_KNIFE,
	AVH_WEAPON_PISTOL,
	AVH_WEAPON_MG,
	AVH_WEAPON_SHOTGUN,
	AVH_WEAPON_HMG,
	AVH_WEAPON_WELDER,
	AVH_WEAPON_MINE,
	AVH_WEAPON_GRENADE_GUN,

	// Abilities
	AVH_ABILITY_LEAP,
	AVH_ABILITY_CHARGE,

	AVH_WEAPON_UMBRA,
	AVH_WEAPON_PRIMALSCREAM,
	AVH_WEAPON_BILEBOMB,
	AVH_WEAPON_ACIDROCKET,
	AVH_WEAPON_HEALINGSPRAY,
	AVH_WEAPON_BABBLER,
	AVH_WEAPON_STOMP,
	AVH_WEAPON_DEVOUR,

	// Can't go over 32 (client.cpp, GetWeaponData())

	AVH_WEAPON_MAX
};
// Struct for the awards (new in 2.0)

typedef struct award_s 
{
	char *name;
	int category;
	int ns_priority;
	int co_priority;
	char *display_pre;
	char *display_post;
} award_t;
typedef struct playeraward_s
{
	// Stuff used to help find awards (not actually used in awards)
	int deadflag; // Player's last known deadflag...
	int iuser4; // Player's last known iuser4 fags...
	int weapons; // Player's last known weapons config...
	int prevteam; // Player's last known team
	int oldclass; // Player's last known iuser3 (class) field 
	int lastimpulse;
	vec3_t oldorigin; // NS's seems buggy?
	// Player flags
	bool display;
	bool connected;
	bool parasited;
	// Awards stuff
	int lifeforms; // res spent on life forms
	float damage;	// Damage this player has done
	int electricity; // Times zapped
	int shots; // Shots fired
	int waste; // Res wasted when you died
	int deaths;	// Player deaths
	int suicides;
	int tks;
	int gestdeaths;
	int builtstructures;
	int devourkills;
	int xenokills;
	int stomp;	// How many times they've stomped
	int parasite; // Times parasited (not hit by parasite, but times you've gotten parasited)
	float tdamage; // Damage taken
	int destroyedstructures;
	int devourdeaths;
	float weld; // Time welded
	int knifekills; // Self-Explainatory
	int resspent; // Spent resources (gorge)
	float weldstart; // Used for determining welder time
	int medpacks; // Medpacks received
	int healsprays; // Times healsprayed
	float distance; // Distance travelled
	int shotgun; // Shotgun kills
	int pistol;	// Pistol kills
	int spores; // spore kills
	int umbra; // Umbra shots
	int primal; // primal scream shots
	int grenades; // Times shot a grenade
	int minedeaths;
	int leaps;
	int worldspawn;
	int trigger_hurt;
} playeraward_t;
playeraward_t player[33];
/*
float	g_Damage[33];
int		g_Deaths[33];
int		g_Suicides[33];
int		g_TKs[33];
int		g_GestDeaths[33];
int		g_BuiltStructures[33];
int		g_DevourKills[33];
int		g_XenoKills[33];
int		g_DestroyedStructures[33];
int		g_DevourDeaths[33];
float	g_Weld[33];
int		g_KnifeKills[33];
int		g_ResSpent[33];
float	g_WeldStart[33];
*/
// Register cvar structs..
cvar_t	*cvar_mp_tournamentmode=	NULL;
cvar_t	*cvar_mp_drawdamage=		NULL;

// Messages we're hooking...

int		gmsgHudText2=	0; // For catching end-of-round (at least until GameStatus is deciphered).
int		gmsgDeathMsg=	0; // Obviously
int		gmsgScreenFade=	0; // Ready room...
int		gmsgCountDown=	0; // Counting down to the next round
int		gmsgResetHUD=	0; // Player just respawned...

// Other variables I will need.

int		g_hookedmsg=0; // For message hooking
int		g_hookedmsgpost=0;
edict_t	*g_hookededict;
bool	g_initialized=false;
float	fDisplay=0.0; // When to display the award screen
hudtextparms_t hudtext;
int		g_DisplayScores[33];

int prioritized[AWARD_MAX];
int priority[AWARD_MAX];
// This is the new listing for awards in order. \
// At the beginning of the round, the plugin    \
// will randomize the awards according to       \
// priority.  Awards with same priority will be \
// chosen at random.  This will allow for       \
// fully random displayed awards.               
int roundawards[AWARD_MAX];
int roundawards_count;

// Since it takes a bit more CPU to create the awards display
// I'm going to only create the display one time per round, and store it in a variable
// (Old method was, it created the awards display for every player, which wasted cycles,
// but was so much simpler.)
char *g_MarineAwards;
char *g_AlienAwards;
char *g_GeneralAwards;

char *g_MarineHeader;
char *g_AlienHeader;
char *g_GeneralHeader;

int g_iMarineAwards;
int g_iAlienAwards;
int g_iGeneralAwards;

int g_HighestPriority=0;

int g_Delay=45;


int kHudTextMarineRed	=0;
int kHudTextMarineGreen	=100;
int kHudTextMarineBlue	=200;
int kHudTextAlienRed	=200;
int kHudTextAlienGreen	=100;
int kHudTextAlienBlue	=0;
int kHudTextAllRed		=255;
int kHudTextAllGreen	=255;
int kHudTextAllBlue		=255;
float kHudTextAllX		=0.1;
float kHudTextAllY		=0.1;
float kHudTextAlienX	=0.1;
float kHudTextAlienY	=0.7;
float kHudTextMarineX	=0.1;
float kHudTextMarineY	=0.4;
int kHudTextAllChan		=333;
int kHudTextMarineChan	=334;
int kHudTextAlienChan	=335;

bool UseDamageFix=true;

struct DeathMSGStruct
{
	int		killer;		// Index of the player killing someone else
	int		victim;		// Index of the player dying
	int		weapon;		// Weapon used
} deathmsg;

struct HudText2Struct
{
	int		text;		// Message displayed
	int		autohelp;	// Determines if it is displayed with cl_autohelp set to 0 (0 in the message) or only when it's 1 (1 in the message)
} hudtext2;


int g_NumericalInfo;
int g_WelderStart;
int g_WelderEnd;
int g_HealSpray;
int g_Stomp;
int g_LMG;
int g_Pistol;
int g_Shotgun;
int g_HMG;
int g_Umbra;
int g_Primal;
int g_GrenadeGun;
int g_Leap;

int iiscombat;
// Declare the non-hooking functions here...

void Process_DeathMsg(void);
void Process_HudText2(void);
void DoEndOfRound(void);
void Display_Awards(edict_t *pEntity);
void Reset_Scores(void);
void Reset(int player);
int LogToIndex(char logline[128]); // Converts first param of a log message to their index
char *Get_Awards(int awardtype);
bool Got_Award(int award);
int Get_Winner(int award,int rettype);
bool Have_Award(int awardtype);
char *Get_Award(int awardtype,int awardnum);
int Get_Award_Prioritized(int awardtype, int awardnum);
bool Is_Prioritized(int award);
void Randomize_Awards(int awardtype);
void scan_config(void);
int find_award_index(char *award);

// Initialize all of the awards, set default values to none as displaying...
award_t awards[] = {
	{"damage",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"deaths",		AWARDCAT_NONE,	0,	0,	"", "" },
	{"suicide",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"tk",			AWARDCAT_NONE,	0,	0,	"",	"" },
	{"gest",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"built",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"devkill",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"xenocide",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"destroy",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"healspray",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"medpack",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"devdeaths",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"welder",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"knife",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"stomp",		AWARDCAT_NONE,	0,	0,	"", "" },
	{"parasite",	AWARDCAT_NONE,	0,	0,	"", "" },
	{"shield",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"electricity",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"shots",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"waste",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"distance",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"shotgun",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"pistol",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"spore",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"umbra",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"primal",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"reswhore",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"grenade",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{"mine",		AWARDCAT_NONE,	0,	0,	"", "" },
	{"worldspawn",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"trigger_hurt",	AWARDCAT_NONE,	0,	0,	"",	"" },
	{"leap",		AWARDCAT_NONE,	0,	0,	"",	"" },
	{NULL,	NULL,	NULL,	NULL,	NULL,	NULL}
};
void PlayerPreThink(edict_t *pEntity)
{
	int index=ENTINDEX(pEntity);
	if (player[index].oldorigin != pEntity->v.origin && player[index].oldorigin != Vector(0,0,0)) // player has moved
	{
		if ((pEntity->v.team == 1 || pEntity->v.team == 2) && player[index].prevteam == pEntity->v.team)
		{
			if ((pEntity->v.deadflag == player[index].deadflag) && pEntity->v.deadflag == 0) // Player's not dead...
			{
				if (pEntity->v.iuser3 != 2 && player[index].oldclass != 2)
				{
					float temp = (player[index].oldorigin - pEntity->v.origin).Length();
					if (temp <= 400)
						player[index].distance += temp / DISTANCE_SCALAR;
				}
			}
		}
	}
	player[index].weapons = pEntity->v.weapons;
	player[index].prevteam = pEntity->v.team;
	player[index].oldclass = pEntity->v.iuser3;
	player[index].oldorigin = pEntity->v.origin;
	player[index].lastimpulse = pEntity->v.impulse;
	if (pEntity->v.deadflag != player[index].deadflag)
	{
		if (pEntity->v.deadflag == 0) // Player is just now spawning...
		{
			player[index].parasited=false;
		}
	}
	if ((pEntity->v.iuser4 & 1073741824) && player[index].parasited == false)
	{
		player[index].parasited=true;
		if (pEntity->v.team == 1)
		{
			player[index].parasite++;
		}
	}
	RETURN_META(MRES_IGNORED);
}
int SpawnPost(edict_t *pEntity) 
{
	if(FStrEq(STRING(pEntity->v.classname), "worldspawn"))
	{
		// Do our event catching here.
		g_NumericalInfo=PRECACHE_EVENT(1,"events/NumericalInfo.sc");
		g_WelderStart=PRECACHE_EVENT(1,"events/WelderStart.sc");
		g_WelderEnd=PRECACHE_EVENT(1,"events/WelderEnd.sc");
		g_HealSpray=PRECACHE_EVENT(1,"events/HealingSpray.sc");
		g_Stomp=PRECACHE_EVENT(1,"events/Stomp.sc");
		g_LMG=PRECACHE_EVENT(1,"events/MachineGun.sc");
		g_Pistol=PRECACHE_EVENT(1,"events/Pistol.sc");
		g_Shotgun=PRECACHE_EVENT(1,"events/SonicGun.sc");
		g_HMG=PRECACHE_EVENT(1,"events/HeavyMachineGun.sc");
		g_Umbra=PRECACHE_EVENT(1,"events/UmbraGun.sc");
		g_Primal=PRECACHE_EVENT(1,"events/PrimalScream.sc");
		g_GrenadeGun=PRECACHE_EVENT(1,"events/GrenadeGun.sc");
		g_Leap=PRECACHE_EVENT(1,"events/Leap.sc");
	}
	RETURN_META_VALUE(MRES_IGNORED, 0);
}
int Spawn(edict_t *pEntity) 
{
	if(FStrEq(STRING(pEntity->v.classname), "worldspawn"))
	{
		scan_config(); // Load up config file
		iiscombat=0;
		char mapname[255];
		strcpy(mapname,STRING(gpGlobals->mapname));
		if (mapname[0]=='c' && mapname[1]=='o' && mapname[2]=='_')
			iiscombat=1;

		int i=0;
		for (i=0;i<=32;i++)
		{
			player[i].connected=false;
		}
		// New round starting -- clense all of the arrays.
		// Get cvar pointers...
		cvar_mp_tournamentmode = CVAR_GET_POINTER("mp_tournamentmode");
		cvar_mp_drawdamage = CVAR_GET_POINTER("mp_drawdamage");
		g_initialized=true;
		fDisplay=0.0;
		RETURN_META_VALUE(MRES_HANDLED, 0);
	}

	RETURN_META_VALUE(MRES_IGNORED, 0);
}
void ClientCommand(edict_t *pEntity)
{
	const char* szUserCommand = CMD_ARGV(0);
	if( szUserCommand[0] == '\0' ) return; //to get rid of warnings if the plugin doesn't make any client commands
	if (FStrEq(CMD_ARGV(0),"say") || FStrEq(CMD_ARGV(0),"say_team"))
	{
		if (FStrEq(CMD_ARGV(1),"/close"))
		{
			// General awards
			hudtext.a1 = 0;
			hudtext.a2 = 0;
			hudtext.r2 = 255;
			hudtext.g2 = 255;
			hudtext.b2 = 250;
			hudtext.r1 = kHudTextAllRed;
			hudtext.g1 = kHudTextAllGreen;
			hudtext.b1 = kHudTextAllBlue;
			hudtext.x = kHudTextAllX;
			hudtext.y = kHudTextAllY;
			hudtext.effect = kHudTextEffects;
			hudtext.fxTime = kHudTextfxTime;
			hudtext.holdTime = 0.1;
			hudtext.fadeinTime = kHudTextFadeIn;
			hudtext.fadeoutTime = kHudTextFadeOut;
			hudtext.channel = kHudTextAllChan;
			ClearHudMessage(pEntity,hudtext);
	
			// Marine awards
			hudtext.a1 = 0;
			hudtext.a2 = 0;
			hudtext.r2 = 255;
			hudtext.g2 = 255;
			hudtext.b2 = 250;
			hudtext.r1 = kHudTextMarineRed;
			hudtext.g1 = kHudTextMarineGreen;
			hudtext.b1 = kHudTextMarineBlue;
			hudtext.x = kHudTextMarineX;
			hudtext.y = kHudTextMarineY;
			hudtext.effect = kHudTextEffects;
			hudtext.fxTime = kHudTextfxTime;
			hudtext.holdTime = 0.1;
			hudtext.fadeinTime = kHudTextFadeIn;
			hudtext.fadeoutTime = kHudTextFadeOut;
			hudtext.channel = kHudTextMarineChan;
			ClearHudMessage(pEntity,hudtext);
	
			// Alien awards
			hudtext.a1 = 0;
			hudtext.a2 = 0;
			hudtext.r2 = 255;
			hudtext.g2 = 255;
			hudtext.b2 = 250;
			hudtext.r1 = kHudTextAlienRed;
			hudtext.g1 = kHudTextAlienGreen;
			hudtext.b1 = kHudTextAlienBlue;
			hudtext.x = kHudTextAlienX;
			hudtext.y = kHudTextAlienY;
			hudtext.effect = kHudTextEffects;
			hudtext.fxTime = kHudTextfxTime;
			hudtext.holdTime = 0.1;
			hudtext.fadeinTime = kHudTextFadeIn;
			hudtext.fadeoutTime = kHudTextFadeOut;
			hudtext.channel = kHudTextAlienChan;
			ClearHudMessage(pEntity,hudtext);
			RETURN_META(MRES_SUPERCEDE);
		}
		else if (FStrEq(CMD_ARGV(1),"/awards"))
		{
			if( g_DisplayScores[ENTINDEX(pEntity)] )
			{
				if (pEntity->v.team == 0)
				{
					Display_Awards(pEntity);
				}
			}
		}
	}
	RETURN_META(MRES_IGNORED);
}
void ClientPutInServer(edict_t *pEntity)
{
	int i=ENTINDEX(pEntity);
	player[i].connected=true;
	player[i].display=false;
	Reset(i);
	RETURN_META(MRES_IGNORED);
}
void ClientDisconnect(edict_t *pEntity)
{
	int i=ENTINDEX(pEntity);
	player[i].display=false;
	player[i].connected=false;
	Reset(i);
	RETURN_META(MRES_IGNORED);
}
void MessageBeginPost(int msg_type, int msg_name, const float *pOrigin, edict_t *pEntity)
{
	g_hookededict=NULL;
	if (gmsgScreenFade==0)
		gmsgScreenFade = GET_USER_MSG_ID(&Plugin_info, "ScreenFade", NULL);
	if (gmsgCountDown==0)
		gmsgCountDown = GET_USER_MSG_ID(&Plugin_info, "Countdown", NULL);
	if (gmsgResetHUD==0)
		gmsgResetHUD = GET_USER_MSG_ID(&Plugin_info, "ResetHUD", NULL);
	g_hookedmsgpost=msg_name;
	if (msg_name == gmsgScreenFade)
	{
		if (pEntity)
		{
			if (pEntity->v.team == 0 && g_DisplayScores[ENTINDEX(pEntity)])
			{
				g_hookededict=pEntity;
			}
		}
	}
	else if (msg_name == gmsgResetHUD)
	{
		if (pEntity)
		{
			player[ENTINDEX(pEntity)].parasited=false;
		}
	}
	else if (msg_name == gmsgCountDown) // Starting a new round here.. stop showing scores!
	{
		int i;
		for (i=0;i<=32;i++)
			g_DisplayScores[i]=false;
		Reset_Scores();
	}
	RETURN_META(MRES_IGNORED);
}
void MessageEndPost(void)
{
	if (g_hookedmsgpost==gmsgHudText2)
	{
		Process_HudText2();
	}
	else if (g_hookedmsgpost==gmsgScreenFade)
	{
		if (g_hookededict != NULL)
		{
				g_DisplayScores[ENTINDEX(g_hookededict)]=false;
				Display_Awards(g_hookededict);
				g_hookededict=NULL;
		}
	}
	RETURN_META(MRES_IGNORED);
}
void MessageBegin(int msg_type,int msg_name, const float *pOrigin, edict_t *pEntity)
{
	if (gmsgHudText2==0)
		gmsgHudText2 = GET_USER_MSG_ID(&Plugin_info, "HudText2", NULL);
	if (gmsgDeathMsg==0)
		gmsgDeathMsg = GET_USER_MSG_ID(&Plugin_info, "DeathMsg", NULL);
	if (gmsgScreenFade==0)
		gmsgScreenFade = GET_USER_MSG_ID(&Plugin_info, "ScreenFade", NULL);
	g_hookedmsg=msg_name;
	if (g_hookedmsg == gmsgDeathMsg)
	{
		deathmsg.killer=-1;
		deathmsg.victim=-1;
		deathmsg.weapon=NULL;
	}
	else if (g_hookedmsg == gmsgHudText2)
	{
		hudtext2.text=NULL;
		hudtext2.autohelp=0;
	}
	RETURN_META(MRES_IGNORED);
}
void MessageEnd()
{
	if (g_hookedmsg==0)
		RETURN_META(MRES_IGNORED);
	if (g_hookedmsg==gmsgDeathMsg)
	{
		Process_DeathMsg();
	}
	g_hookedmsg=0;
	RETURN_META(MRES_IGNORED);
}
void WriteByte(int i)
{
	if (g_hookedmsg == gmsgDeathMsg)
	{
		if (deathmsg.killer == -1)
			deathmsg.killer = i;
		else
			deathmsg.victim = i;
	}
	else if (g_hookedmsg == gmsgHudText2)
	{
		hudtext2.autohelp=0;
	}
	RETURN_META(MRES_IGNORED);
}
void WriteString(const char *s)
{
	if (g_hookedmsg == gmsgDeathMsg)
	{
		deathmsg.weapon=MAKE_STRING(s);
	}
	else if (g_hookedmsg == gmsgHudText2)
	{
		hudtext2.text=MAKE_STRING(s);
	}
	RETURN_META(MRES_IGNORED);
}

void StartFrame()
{
	if (g_initialized == false)
		RETURN_META(MRES_IGNORED);
	if (cvar_mp_tournamentmode->value == 1.0)
		RETURN_META(MRES_IGNORED);
	if (cvar_mp_drawdamage->value != 1.0)
	{
		cvar_mp_drawdamage->value = 1.0;
		strcpy(cvar_mp_drawdamage->string,"1\0");
	}
	RETURN_META(MRES_HANDLED);
}
void PlaybackEvent(int flags, const edict_t *pInvoker, unsigned short eventindex, float delay, float *origin, float *angles, float fparam1, float fparam2, int iparam1, int iparam2, int bparam1, int bparam2)
{
	edict_t *pEntity = (edict_t *)pInvoker;
	int index;
	if (eventindex == g_NumericalInfo) // Find damage text.
	{
		if (FNullEnt(pEntity))
			RETURN_META(MRES_IGNORED);
		if (iparam1 == 1)
		{
			if (fparam1 < 0)
			{
				if (pEntity)
				{
					if (ENTINDEX(pEntity) > 0 && ENTINDEX(pEntity) <= gpGlobals->maxClients)
					{
						player[ENTINDEX(pEntity)].tdamage-=fparam1;
					}
				}
				if (!FNullEnt(pInvoker->v.dmg_inflictor))
				{
					if (FStrEq(STRING(pInvoker->v.dmg_inflictor->v.classname),"resourcetower") || FStrEq(STRING(pInvoker->v.dmg_inflictor->v.classname),"team_turretfactory") || FStrEq(STRING(pInvoker->v.dmg_inflictor->v.classname),"team_advturretfactory"))
					{
						if (ENTINDEX(pEntity) > 0 && ENTINDEX(pEntity) <= gpGlobals->maxClients)
						{
							player[ENTINDEX(pEntity)].electricity++;
						}
					}
					else if (!FNullEnt(pInvoker->v.dmg_inflictor->v.owner))
					{
						index=ENTINDEX(pInvoker->v.dmg_inflictor->v.owner);
						if (index > 0 && index < 33)
						{
							player[index].damage-=fparam1;
						}
					}
				}
			}
			else if (fparam1 > 0)
			{
				// +health message (medpack)
				if (!FNullEnt(pEntity) && ENTINDEX(pEntity) > 0 && ENTINDEX(pEntity) < 32)
				{
					if (pEntity->v.team == 1) // just in case
						player[ENTINDEX(pEntity)].medpacks++;
				}
			}
			if (cvar_mp_damagedraw->value == 1.0)
			{
				RETURN_META(MRES_IGNORED);
			}
			else
			{
				RETURN_META(MRES_SUPERCEDE);
			}
		}
	}
	else if (eventindex == g_WelderStart)
	{
		if (FNullEnt(pEntity))
			RETURN_META(MRES_IGNORED);
		index=ENTINDEX(pEntity);
		if (index > 0 && index <= gpGlobals->maxClients)
		{
			player[index].weldstart=gpGlobals->time;
		}
		RETURN_META(MRES_IGNORED);
	}
	else if (eventindex == g_WelderEnd)
	{
		if (FNullEnt(pEntity))
			RETURN_META(MRES_IGNORED);
		index=ENTINDEX(pEntity);
		if (index > 0 && index <= gpGlobals->maxClients)
		{

			if (player[index].weldstart>0.0)
			{
				player[ENTINDEX(pEntity)].weld+=gpGlobals->time - player[ENTINDEX(pEntity)].weldstart;
				player[ENTINDEX(pEntity)].weldstart=0.0;
			}
		}
		RETURN_META(MRES_IGNORED);
	}
	else if (eventindex == g_HealSpray)
	{
		if (FNullEnt(pEntity))
			RETURN_META(MRES_IGNORED);
		player[ENTINDEX(pEntity)].healsprays++;
		RETURN_META(MRES_IGNORED);
	}
	else if (eventindex == g_Stomp)
	{
		if (FNullEnt(pEntity))
			RETURN_META(MRES_IGNORED);
		if (ENTINDEX(pEntity) < 1 || ENTINDEX(pEntity) > gpGlobals->maxClients)
			RETURN_META(MRES_IGNORED);
		player[ENTINDEX(pEntity)].stomp++;
		RETURN_META(MRES_IGNORED);
	}
	else if (eventindex == g_LMG || eventindex == g_Pistol || eventindex == g_HMG || eventindex == g_Shotgun)
	{
		if (!FNullEnt(pEntity))
		{
			index = ENTINDEX(pEntity);
			if (index > 0 && index <= gpGlobals->maxClients)
			{
				player[index].shots++;
			}
		}
	}
	else if (eventindex == g_Umbra)
	{
		if (!FNullEnt(pEntity))
		{
			index = ENTINDEX(pEntity);
			if (index > 0 && index <= gpGlobals->maxClients)
			{
				player[index].umbra++;
			}
		}
	}
	else if (eventindex == g_Primal)
	{
		if (!FNullEnt(pEntity))
		{
			index=ENTINDEX(pEntity);
			if (index > 0 && index <= gpGlobals->maxClients)
			{
				player[index].primal++;
			}
		}
	}
	else if (eventindex == g_GrenadeGun)
	{
		if (!FNullEnt(pEntity))
		{
			index=ENTINDEX(pEntity);
			if (index > 0 && index<= gpGlobals->maxClients)
			{
				player[index].grenades++;
			}
		}
	}
	else if (eventindex == g_Leap)
	{
		if (!FNullEnt(pEntity))
		{
			index=ENTINDEX(pEntity);
			if (index > 0 && index<=gpGlobals->maxClients)
			{
				player[index].leaps++;
			}
		}
	}
	RETURN_META(MRES_IGNORED);
}

void AlertMessage(ALERT_TYPE atype, char *szFmt, ...)
{
	if (iiscombat == 1)
		RETURN_META(MRES_IGNORED);
	if (atype != at_logged)
		RETURN_META(MRES_IGNORED);

	va_list LogArg;
	char *sz, *message;
	const char *b;
	char szParm[5][128];
	int argc,len;
	va_start(LogArg, szFmt);
	sz = va_arg(LogArg, char *);
	va_end(LogArg);
	message = sz;
	b=message;
	argc=0;
	// Parse the damn message
	while (*b && *b!='\0' && argc<5)
	{

		len=0;
		if (*b == '"')
		{
			b++; // Skip over the "
			while (*b && *b != '"' && len < 127)
			{
				szParm[argc][len]=*b;
				b++;
				len++;
			}
			//*szParm='\0';
			szParm[argc][len]='\0';
			if (*b && *b == '"' && *b+1 != '\0' && *b+2 != '\0')
			{
				b+=2;
				argc++;
			}
			else
			{
				argc++;
				break;
			}
		}
		else if (*b == '(')
		{
			b++; // Skip over the (
			while (*b && *b != ')' && len < 127)
			{
				szParm[argc][len]=*b;
				b++;
				len++;
			}
			szParm[argc][len]='\0';
			if (*b && *b == ')' && *b+1 != '\0' && *b+2 != '\0')
			{
				b+=2;
				argc++;
			}
			else
			{
				argc++;
				break;
			}
		}
		else
		{
			while (*b && *b != '"' && *b != '(' && len < 127)
			{
				szParm[argc][len]=*b;
				b++;
				len++;
			}
			szParm[argc][len]='\0';
			if (*b != '"' && *b != '(' && *b != '\0' && *b+1 != '\0' && *b+2 != '\0')
			{
				b+=2;
				argc++;
			}
			else
			{
				argc++;
				if (*b == '\0')
					break;
			}

		}
		
		
	}
	if (argc == 3) // "player" changed role to "gestate"
	{
		if (FStrEq((const char *)szParm[1],"changed role to "))
		{
			if (FStrEq((const char *)szParm[2],"gestate"))
			{
				int index=LogToIndex(szParm[0]);
				if (player[index].lastimpulse == 117) // Onos
				{
					player[index].lifeforms+=COST_ONOS;
				}
				else if (player[index].lastimpulse == 116) // fade
				{
					player[index].lifeforms+=COST_FADE;
				}
				else if (player[index].lastimpulse == 115) // lerk
				{
					player[index].lifeforms+=COST_LERK;
				}
				else if (player[index].lastimpulse == 114) // gorge
				{
					player[index].lifeforms+=COST_GORGE;
				}
				else if (player[index].lastimpulse == 113) // skulk..
				{
					player[index].lifeforms+=COST_SKULK;
				}
				else if (player[index].lastimpulse >= 101 && player[index].lastimpulse <= 112)
				{
					player[index].lifeforms+=COST_UPGRADE;
				}

			}
		}
	}
	if (argc == 4) // structure_built / structure_destroyed are 4 long
	{
		if (FStrEq((const char *)szParm[2],"structure_built"))
		{
			int index=LogToIndex(szParm[0]);
			if (FStrEq((const char *)szParm[3],"type \"team_hive\""))
			{
				player[index].builtstructures+=POINTS_BUILT_HIVE;
			}
			else if (FStrEq((const char *)szParm[3],"type \"alienresourcetower\""))
			{
				player[index].builtstructures+=POINTS_BUILT_RT;
			}
			else if (FStrEq((const char *)szParm[3],"type \"offensechamber\""))
			{
				player[index].builtstructures+=POINTS_BUILT_OC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"movementchamber\""))
			{
				player[index].builtstructures+=POINTS_BUILT_MC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"defensechamber\""))
			{
				player[index].builtstructures+=POINTS_BUILT_DC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"sensorychamber\""))
			{
				player[index].builtstructures+=POINTS_BUILT_SC;
			}
		}
		else if (FStrEq((const char *)szParm[2],"structure_destroyed"))
		{
			int index=LogToIndex(szParm[0]);
			if (FStrEq((const char *)szParm[3],"type \"team_hive\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_HIVE;
			}
			else if (FStrEq((const char *)szParm[3],"type \"alienresourcetower\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_RT;
			}
			else if (FStrEq((const char *)szParm[3],"type \"offensechamber\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_OC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"movementchamber\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_MC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"defensechamber\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_DC;
			}
			else if (FStrEq((const char *)szParm[3],"type \"sensorychamber\""))
			{
				player[index].destroyedstructures+=POINTS_KILL_SC;
			}
		}
	}
	RETURN_META(MRES_IGNORED);
}
// Non-hooking functions

int LogToIndex(char logline[128])
{
	char *cname;
	// Format of log line:
	// name<CID><auth><team>
	// We need to find their ID from their name...
	int x,y=0;
	char cindex[64];
	// first we find the location of the start of the index
	// Name can contain <>'s, so we go from the end up.
	for (x=strlen(logline);x>=0;x--)
	{
		if (logline[x]=='<')
		{
			y++;
			if (y==3)
			{
				y=x;
				break;
			}
		}
	}
	// We found the end of the name, now copy the rest down.
	y--;
	x=0;
	for (x;x<=y;x++)
	{
		cindex[x]=logline[x];
	}
	cindex[x]='\0';
	// Now we have their name, now cycle through all players to find which index it is
	x=1;
	for (x;x<=gpGlobals->maxClients;x++)
	{
		cname=strdup(cindex);
		if (!FNullEnt(INDEXENT(x)))
		{
			if (FStrEq(cname,STRING(INDEXENT(x)->v.netname)))
			{
				return x;
			}
		}
	}
	return 0;
}
void Process_HudText2(void)
{
	if (FStrEq(STRING(hudtext2.text),"TeamOneWon") || FStrEq(STRING(hudtext2.text),"TeamTwoWon") || FStrEq(STRING(hudtext2.text),"GameDraw"))
	{
		g_GeneralAwards = strdup(Get_Awards(AWARDCAT_GENERAL));
		g_MarineAwards = strdup(Get_Awards(AWARDCAT_MARINE));
		g_AlienAwards = strdup(Get_Awards(AWARDCAT_ALIEN));
		edict_t *pEntity=NULL;
		int i=0;
		for (i=1;i<=gpGlobals->maxClients;i++)
		{
			pEntity=INDEXENT(i);
			if (pEntity && !pEntity->free)
			{
				if (g_DisplayScores[i]==false)
				{
					g_DisplayScores[i]=true;
					// If people are in the ready room at the end of the round, show the awards instantly.
					if (INDEXENT(i)->v.team == 0)
					{
						g_DisplayScores[i]=2;  // Set it to a state so it only displays this one time
						Display_Awards(INDEXENT(i));
					}
				}
			}
		}
	}
}
void Process_DeathMsg(void)
{
	/* TEMPORARY FIX FOR MP_DRAWDAMAGE ANOMALIES */
	edict_t *pEntity=INDEXENT(deathmsg.victim);
	if (UseDamageFix)
	{
		if (deathmsg.victim > 0 && deathmsg.killer > 0 && deathmsg.victim <= gpGlobals->maxClients && deathmsg.killer <= gpGlobals->maxClients)
		{
			if (pEntity->v.dmg_take > 0 && pEntity->v.dmg_take <= 235) // No player made damage can be higher than this... (lvl 3 focus + primal gore = 232.83)
			{
				player[deathmsg.victim].tdamage+=pEntity->v.dmg_take;
				if (!FNullEnt(pEntity->v.dmg_inflictor))
				{
					if (!FNullEnt(pEntity->v.dmg_inflictor->v.owner))
					{
						if (ENTINDEX(pEntity->v.dmg_inflictor->v.owner) > 0 && ENTINDEX(pEntity->v.dmg_inflictor->v.owner) <= gpGlobals->maxClients)
						{
							player[ENTINDEX(pEntity->v.dmg_inflictor->v.owner)].damage+=pEntity->v.dmg_take;
						}
					}
				}
			}
		}
	}
	player[deathmsg.victim].deaths++;
	if (player[deathmsg.victim].weldstart != 0) // If they were welding when they died, then count the time welded
	{
		player[deathmsg.victim].weld+=gpGlobals->time - player[deathmsg.victim].weldstart;
		player[deathmsg.victim].weldstart=0;
	}
	// Check for waste of res award...
	int res=0;
	if (pEntity->v.team == 1) // Marine
	{
		if (pEntity->v.iuser4 & 32768)
			res+=COST_HEAVY;
		if (pEntity->v.iuser4 & 512)
			res+=COST_JETPACK;
		if (player[deathmsg.victim].weapons & (1<<AVH_WEAPON_HMG))
			res+=COST_HMG;
		if (player[deathmsg.victim].weapons & (1<<AVH_WEAPON_SHOTGUN))
			res+=COST_SHOTGUN;
		if (player[deathmsg.victim].weapons & (1<<AVH_WEAPON_GRENADE_GUN))
			res+=COST_GRENADELAUNCHER;
		if (player[deathmsg.victim].weapons & (1<<AVH_WEAPON_WELDER))
			res+=COST_WELDER;
		if (player[deathmsg.victim].weapons & (1<<AVH_WEAPON_MINE))
			res+=COST_MINE;
		player[deathmsg.victim].waste+=res;
	}
	if (FStrEq(STRING(INDEXENT(deathmsg.victim)->v.model),"models/player/gestate/gestate.mdl")) // Player died as an egg
	{
		player[deathmsg.victim].gestdeaths++;
	}
	if (deathmsg.killer != deathmsg.victim && deathmsg.killer != 0)
	{
		if (INDEXENT(deathmsg.killer)->v.team == INDEXENT(deathmsg.victim)->v.team)
			player[deathmsg.killer].tks++;
	}
	if (deathmsg.killer == deathmsg.victim || deathmsg.killer == 0) // Suicide
	{
		if (FStrEq(STRING(deathmsg.weapon),"item_mine"))
			player[deathmsg.victim].minedeaths++;
		if (!FStrEq(STRING(deathmsg.weapon),"divinewind") && !FStrEq(STRING(deathmsg.weapon),"offensechamber") && !FStrEq(STRING(deathmsg.weapon),"item_mine") && !FStrEq(STRING(deathmsg.weapon),"turret") && !FStrEq(STRING(deathmsg.weapon),"siegeturret") && !FStrEq(STRING(deathmsg.weapon),"resourcetower") && !FStrEq(STRING(deathmsg.weapon),"team_turretfactory") && !FStrEq(STRING(deathmsg.weapon),"team_advturretfactory")) // Don't count these as suicides (if they kill self with them only)
		{
			if (FStrEq(STRING(deathmsg.weapon),"worldspawn"))
				player[deathmsg.victim].worldspawn++;
			else if (FStrEq(STRING(deathmsg.weapon),"trigger_hurt"))
				player[deathmsg.victim].trigger_hurt++;
			else
				player[deathmsg.victim].suicides++;
		}
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"knife")) // Knife kill
	{
		player[deathmsg.killer].knifekills++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"devour")) // Devour
	{
		player[deathmsg.victim].devourdeaths++;
		player[deathmsg.killer].devourkills++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"divinewind")) // Xenocide
	{
		player[deathmsg.killer].xenokills++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"shotgun")) // Shotgun kills
	{
		player[deathmsg.killer].shotgun++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"pistol")) // Shotgun kills
	{
		player[deathmsg.killer].pistol++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"item_mine"))
	{
		player[deathmsg.victim].minedeaths++;
		return;
	}

	else if (FStrEq(STRING(deathmsg.weapon),"resourcetower") || FStrEq(STRING(deathmsg.weapon),"team_turretfactory") || FStrEq(STRING(deathmsg.weapon),"team_advturretfactory"))
	{
		// NS's problem with mp_drawdamage leads to inaccurate electricity count.  Compensate by counting the fatal electric shot as a zap.
		player[deathmsg.victim].electricity++;
		return;
	}
	else if (FStrEq(STRING(deathmsg.weapon),"sporegunprojectile"))
	{
		player[deathmsg.killer].spores++;
		return;
	}
}
void Reset_Scores(void)
{
	int i;
	for (i=0;i<=32;i++)
	{
		player[i].display=false;
		Reset(i);
	}

}
#include "awarddisplay.h"
void Reset(int i)
{
	player[i].lastimpulse=0;
	player[i].stomp=0;
	player[i].tdamage=0;
	player[i].parasite=0;
	player[i].builtstructures=0;
	player[i].damage=0.0;
	player[i].deaths=0;
	player[i].destroyedstructures=0;
	player[i].devourdeaths=0;
	player[i].devourkills=0;
	player[i].gestdeaths=0;
	player[i].healsprays=0;
	player[i].knifekills=0;
	player[i].medpacks=0;
	player[i].resspent=0;
	player[i].suicides=0;
	player[i].tks=0;
	player[i].weld=0.0;
	player[i].weldstart=0.0;
	player[i].xenokills=0;
	player[i].parasited=false;
	player[i].electricity=0;
	player[i].shots=0;
	player[i].waste=0;
	player[i].distance=0.0;
	player[i].oldorigin=Vector(0,0,0);
	player[i].shotgun=0;
	player[i].pistol=0;
	player[i].spores=0;
	player[i].umbra=0;
	player[i].primal=0;
	player[i].lifeforms=0;
	player[i].grenades=0;
	player[i].minedeaths=0;
	player[i].leaps=0;
	player[i].worldspawn=0;
	player[i].trigger_hurt=0;
}
#include "configfile.h"
