int find_award_index(char *award)
{
	int i=0;
	if (strlen(award) == 0)
		return -1;

	while (awards[i].name)
	{
		if (FStrEq(award,awards[i].name))
			return i;
		i++;
	}
	return -1;
}
void scan_config(void)
{
	char *data;
	int length=0;
	char *datafile=cvar_mp_awardsfile->string;
	char param[7][128];
	char line[1024];
	int argc=0;
	int x,y;
	int index;
	// Config file not found...
	if (strlen(datafile) == 0)
	{
		LOG_ERROR(PLID, "No config file set.");
		return;
	}
    data=(char*)LOAD_FILE_FOR_ME(datafile, &length);
	// Config file found, but no data found...
	if (!data || length<=0)
	{
		LOG_ERROR( PLID, "Couldn't open file %s\n", datafile);
		return;
	}
	// We have the data dumped to "data", now parse it all :/
	line[0]='\0';
	int itemp=0;
	while (*data && *data != '\0')
	{
		if (*data!='\n' && *data!='\r' && *data!='\0')
		{
			if (itemp<1023)
			{
				line[itemp]=*data;
				itemp++;
			}
			data++;
		}
		else
		{
			line[itemp]='\0'; // Null off the string...
			if (*data!='\0')
				data++;
			// We have our single line, now scan the line for the 6 parameters.
			// Format: "name" "category" "nspriority" "copriority" "Display:" "%s (asdf %i)"
			argc=0;
			x=0;
			y=0;
			param[0][0]='\0';
			param[1][0]='\0';
			param[2][0]='\0';
			param[3][0]='\0';
			param[4][0]='\0';
			param[5][0]='\0';
			if (line[0] != '/')
			{
				while (x<1023 && line[x]!='\0' && line[x] && argc<7)
				{
					if (line[x] == '"')
					{
						y=0;
						x++; // Skip over the "
						while (line[x]!='"'&&line[x]!='\0')
						{
							if (line[x]=='\\') // Check for \" (To allow for "'s in the award names, etc.)
							{
								if (x < strlen(line))
								{
									if (line[x+1]=='"')
									{
										x++; // Just skip over the '\'
									}
								}
							}
							param[argc][y]=line[x];
							x++;
							y++;
							if (line[x]=='"'||line[x]=='\0')
							{
								param[argc][y]='\0';
								argc++;
							}
						}
					}
					x++;
				}
				// Now process this line's parameters...
				if (FStrEq(param[0],"award"))
				{
					index=find_award_index(param[1]);
					if (index >= 0) // Check if it's a valid award...
					{
						// Format: "name" "category" "nspriority" "copriority" "Display:" "%s (asdf %i)"
						// Check category...
						if (FStrEq(param[2],"g") || FStrEq(param[2],"G"))
							awards[index].category=AWARDCAT_GENERAL;
						else if (FStrEq(param[2],"a") || FStrEq(param[2],"A"))
							awards[index].category=AWARDCAT_ALIEN;
						else if (FStrEq(param[2],"m") || FStrEq(param[2],"M"))
							awards[index].category=AWARDCAT_MARINE;
						else if (FStrEq(param[2],"n") || FStrEq(param[2],"N"))
							awards[index].category=AWARDCAT_NONE;
						// Log priorities...
						awards[index].ns_priority = atoi(param[3]);
						awards[index].co_priority = atoi(param[4]);
						if (awards[index].co_priority > g_HighestPriority)
							g_HighestPriority=awards[index].co_priority;
						if (awards[index].ns_priority > g_HighestPriority)
							g_HighestPriority=awards[index].ns_priority;
						// Log the award name...
						awards[index].display_pre = strdup(param[5]);
						awards[index].display_post = strdup(param[6]);
					}
				}
				else if (FStrEq(param[0],"config"))
				{
					if (FStrEq(param[1],"damagefix"))
						UseDamageFix=atoi(param[2]);
					else if (FStrEq(param[1],"general"))
						g_iGeneralAwards=atoi(param[2]);
					else if (FStrEq(param[1],"marine"))
						g_iMarineAwards=atoi(param[2]);
					else if (FStrEq(param[1],"alien"))
						g_iAlienAwards=atoi(param[2]);
					else if (FStrEq(param[1],"gheader"))
						g_GeneralHeader=strdup(param[2]);
					else if (FStrEq(param[1],"mheader"))
						g_MarineHeader=strdup(param[2]);
					else if (FStrEq(param[1],"aheader"))
						g_AlienHeader=strdup(param[2]);
					else if (FStrEq(param[1],"delay"))
						g_Delay=atoi(param[2]);
					else if (FStrEq(param[1],"display"))
					{
						if (FStrEq(param[2],"general"))
						{
							if (FStrEq(param[3],"r"))
								kHudTextAllRed=atoi(param[4]);
							else if (FStrEq(param[3],"g"))
								kHudTextAllGreen=atoi(param[4]);
							else if (FStrEq(param[3],"b"))
								kHudTextAllBlue=atoi(param[4]);
							else if (FStrEq(param[3],"x"))
								kHudTextAllX=atof(param[4]);
							else if (FStrEq(param[3],"y"))
								kHudTextAllY=atof(param[4]);
							else if (FStrEq(param[3],"channel"))
								kHudTextAllChan=atoi(param[4]);
						}
						else if (FStrEq(param[2],"marine"))
						{
							if (FStrEq(param[3],"r"))
								kHudTextMarineRed=atoi(param[4]);
							else if (FStrEq(param[3],"g"))
								kHudTextMarineGreen=atoi(param[4]);
							else if (FStrEq(param[3],"b"))
								kHudTextMarineBlue=atoi(param[4]);
							else if (FStrEq(param[3],"x"))
								kHudTextMarineX=atof(param[4]);
							else if (FStrEq(param[3],"y"))
								kHudTextMarineY=atof(param[4]);
							else if (FStrEq(param[3],"channel"))
								kHudTextMarineChan=atoi(param[4]);
						}
						else if (FStrEq(param[2],"alien"))
						{
							if (FStrEq(param[3],"r"))
								kHudTextAlienRed=atoi(param[4]);
							else if (FStrEq(param[3],"g"))
								kHudTextAlienGreen=atoi(param[4]);
							else if (FStrEq(param[3],"b"))
								kHudTextAlienBlue=atoi(param[4]);
							else if (FStrEq(param[3],"x"))
								kHudTextAlienX=atof(param[4]);
							else if (FStrEq(param[3],"y"))
								kHudTextAlienY=atof(param[4]);
							else if (FStrEq(param[3],"channel"))
								kHudTextAlienChan=atoi(param[4]);
						}
					}
				}
			}
			// Reset the line.
			itemp=0;
			line[itemp]='\0';
		}
	}
}
