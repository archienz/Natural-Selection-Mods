
#include "plugin.h"
#include <sdk_util.h>	//pre-defined function definitions saves us a lot of work
#include <cbase.h>
#include <player.h>

#undef DEFINE_CVAR
#define DEFINE_CVAR(cvarname, cvarflags, cvarstringvalue, cvarfloatvalue)\
	cvar_t cvarname ## _register = { "" #cvarname "", cvarstringvalue, cvarflags, cvarfloatvalue };\
	cvar_t * cvar_ ## cvarname;
#define SETTING_UP_CVARS_AND_COMMANDS
#include "plugin.h"
#undef SETTING_UP_CVARS_AND_COMMANDS

void plugin_init(void) {
	UTIL_LogPrintf( "[" MY_LOGTAG "] Loading.  Version: " MY_VERSION "\n");

	#undef DEFINE_CVAR
	#define DEFINE_CVAR(cvarname, cvarflags, cvarstringvalue, cvarfloatvalue) \
		CVAR_REGISTER(&cvarname ## _register ); cvar_ ## cvarname = CVAR_GET_POINTER( "" #cvarname "" );
	#define SETTING_UP_CVARS_AND_COMMANDS
	#include "plugin.h"
	#undef SETTING_UP_CVARS_AND_COMMANDS

	//static cvar_t plugin_version_register = { MY_CVARNAME "_version", MY_VERSION, FCVAR_SERVER | FCVAR_SPONLY | FCVAR_PRINTABLEONLY, 0 };
	//CVAR_REGISTER( &plugin_version_register );
}


void plugin_quit(void)
{
	UTIL_LogPrintf( "[" MY_LOGTAG "] Unloading.  Version: " MY_VERSION "\n");
}




