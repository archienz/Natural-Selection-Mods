
#define ABSOLUTE_VALUE_EASY(x) (((x) < 0) ? (-(x)) : (x)) //very useful for gpGlobals->time comparisons
void HudMessage(edict_t *pEntity, const hudtextparms_t &textparms, const char *pMessage);
void ClearHudMessage(edict_t *pEntity, const hudtextparms_t &textparms);