To use: Load like any other metamod plugin.

Note: The plugin will automatically turn mp_drawdamage on, however,
  it has a cvar to determine if the damage display is drawn or not.

Cvars:

mp_awards
 - Just the version of the plugin

mp_damagedraw
 - Whether or not to display the mp_drawdamage text. 1=display, 0=do not display

mp_awardsfile
 - Location of the awards config file. (default: awards.ini)

Commands:

  say /close - Removes the awards display

About the config file:

The config file is REQUIRED to operate.  It is to be located in the NS folder (ie: /home/steve/hlds_l/nsp/awards.ini)

The default name is awards.ini.

Open up the provided awards.ini file for format and examples.

If you need further help, post in the release thread at:
http://www.modns.org/forums/index.php?showtopic=329