/**************************************************************************************************
For use with Climbing Maps
http://www.kreedz.com/
And Other Climbing Maps

List Maps & Configurations in climbing.ini


**** CVARS (FEATURES) ****
kz_autoheal    = AutoHeal
kz_autospawn   = AutoSpawn
kz_bunnyjump   = 1 = No slowdown after jumping | 2 = Just hold down jump to bunny hop
kz_godmode     = AutoGodmode
kz_semiclip    = AutoSemiClip
kz_scout       = AutoScout
kz_nightvision = Free NVG
kz_nightmode   = Nightmode
kz_checkpoints = Checkpoints 
kz_timer       = IndividualTimer
kz_top15       = Top15 (BETA)

**** CVARS (CHECKPOINT SYSTEM) ****
kz_checkprice	  = Price of a checkpoint
kz_checkpointdist = Distance from other people you can spawn
kz_checkeffects	  = Some cool teleport effects
kz_limitedcp      = Limit each checkpoint to one use
kz_startmoney     = Instead of mp_startmoney

**** CVARS (OTHER) ****
kz_grabforce = Grabforce for JediGrab

**** ADMIN COMMANDS ****

ADMIN_LEVEL_A (flag="m")
Setting Noclip			= amx_noclip <authid, nick, @team, @all or #userid> <on/off>
Setting Godmode			= amx_godmode <authid, nick, @team, @all or #userid> <on/off>
Setting Semiclip		= amx_semiclip <authid, nick, @team, @all or #userid> <on/off>
Setting Glow			= amx_glow <authid, nick, @team, @all or #userid> <red> <green> <blue> <alpha>
Setting Origin			= amx_teleport <authid, nick or #userid> <authid, nick or #userid>
Setting Gravity			= amx_gravity <authid, nick, @team, @all or #userid> <Gravity>
Granting Hook/Rope		= amx_granthook <authid, nick, @team, @all or #userid> <on/off>

ADMIN_LEVEL_B (flag="n")
Giving Longjump			= amx_longjump <authid, nick, @team, @all or #userid>
Giving Scout			= amx_scout <authid, nick, @team, @all or #userid>
Giving Money			= amx_money <authid, nick, @team, @all or #userid> <Money>

ADMIN_LEVEL_C (flag="o")
Set Checkpoint			= amx_checkpoint <authid, nick or #userid>
Rem Checkpoint			= amx_remcheckpoint <authid, nick or #userid>

ADMIN_LEVEL_D (flag="p")
Jedi Force Grab by Spacedude (slightly modified)
Grabbing a person		= +grab
Releasing grabbed		= -grab
Toggle Command			= grab_toggle

ADMIN_LEVEL_E (flag="q") || Granted by admin
Ninja Rope by Spacedude (slightly modified) & Hook thingy
Attaching Rope			= +rope
Deattaching Rope		= -rope
Attaching Hook			= +hook
Deattaching Hook		= -hook

**** USER COMMANDS ****

checkpoint			= Use Checkpoint
	/checkpoint
gocheck				= Goto Checkpoint
	/gocheck
lastcheck			= Goto Checkpoint before last (used when stuck)
	/stuck
	/unstuck
	/destuckme

**************************************************************************************************/
How To Install.

AMXX
1. Unzip kz_multiplugin.zip in your amxmodx folder
2. Add kz_multiplugin.amx(x) in the plugins.ini
3. Install and activate FUN and ENGINE modules